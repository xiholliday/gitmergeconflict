#! /usr/bin/env ruby

def hello
  puts 'hello world'
end

hello()
